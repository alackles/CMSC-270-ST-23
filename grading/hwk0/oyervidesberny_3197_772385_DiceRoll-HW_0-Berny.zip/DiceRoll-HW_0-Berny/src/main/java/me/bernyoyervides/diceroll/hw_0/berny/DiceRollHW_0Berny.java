package me.bernyoyervides.diceroll.hw_0.berny;

public class DiceRollHW_0Berny {

    public static void main(String[] args) {
        for(int i = 0; i < 3;i++){
        Dice d = new Dice();
        System.out.println(d.roll());
        }
    }
}
