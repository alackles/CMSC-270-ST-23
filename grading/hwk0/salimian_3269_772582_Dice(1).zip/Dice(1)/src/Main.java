public class Main {
    public static void main(String[] args) {
        Dice dice = new Dice();
        dice.setSizeNum(6);
        dice.roll();
    }
}
